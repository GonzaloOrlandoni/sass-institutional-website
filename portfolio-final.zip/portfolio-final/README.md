
# Portfolio Final — Gonzalo Orlandoni

Proyecto final listo para entregar: 5 páginas HTML, Bootstrap 5, SASS, AOS (animaciones), SEO y responsive.

## Estructura
- `index.html`, `about.html`, `projects.html`, `skills.html`, `contact.html`
- `assets/css/style.css` (compilado)
- `assets/scss/style.scss` (fuente SASS)
- `assets/js/app.js`
- `assets/img/*` (placeholders)
- `robots.txt`, `sitemap.xml`, `site.webmanifest`

## Correr localmente
Abrir `index.html` en tu navegador. No requiere build.

## SASS
El CSS fue compilado a mano para esta entrega. Podés iterar en `assets/scss/style.scss` y volver a compilar con tu toolchain (Dart Sass, etc.).

## Deploy
1. Subí todo el contenido a tu repo `portfolio-entrega2` (reemplazando/ajustando lo que ya tenés).
2. Activá GitHub Pages (branch `main` o `docs`, carpeta root).
3. La URL final será: `https://gonzaloorlandoni.github.io/portfolio-entrega2/`

## SEO
- Meta description, canonical, Open Graph y sitemap incluidos.
- `robots.txt` permite indexación.

## Accesibilidad
- Estructura semántica, `alt` en imágenes, foco visible, skip-link.
- Contraste respetado (Bootstrap base + custom).

## Animaciones
- AOS (Animate On Scroll) vía CDN + transiciones sutiles en tarjetas.

## Cosas para personalizar
- Reemplazá imágenes `assets/img/project-*.webp` por capturas reales.
- Actualizá enlaces de proyectos.
- Ajustá textos, formación real y redes.
