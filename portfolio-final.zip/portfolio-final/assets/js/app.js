// Inicialización de AOS y utilidades
document.addEventListener('DOMContentLoaded', function () {
  AOS.init({ once: true, duration: 700, offset: 80 });

  // Año dinámico
  const year = new Date().getFullYear();
  const anio = document.getElementById('anioActual');
  if (anio) anio.textContent = year;

  // Activar link actual en navbar
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(a => {
    if (a.getAttribute('href') === current) a.classList.add('active');
  });

  // Toggle de tema
  const themeToggle = document.getElementById('themeToggle');
  const root = document.documentElement;
  const stored = localStorage.getItem('theme') || 'light';
  if (stored === 'dark') root.setAttribute('data-theme', 'dark');
  themeToggle?.addEventListener('click', () => {
    const isDark = root.getAttribute('data-theme') === 'dark';
    root.setAttribute('data-theme', isDark ? 'light' : 'dark');
    localStorage.setItem('theme', isDark ? 'light' : 'dark');
  });
});